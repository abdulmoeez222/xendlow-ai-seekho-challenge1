# Task: Fix Stuck Agent Pipeline

## Root Cause Summary
1. `pipeline_runs` row is never inserted until all 3 agents finish → `/logs/{id}` returns `not_found` → UI stuck forever
2. `generate_candidates()` in `plan.py` has NO try/except → a `429 RESOURCE_EXHAUSTED` kills the entire background task silently
3. Backend returns `"insight_report"` but Flutter polls for `"insight"` → Analyst step never advances
4. If Phase 1 crashes, `pipeline_runs` is never updated to `failed` → UI hangs with no feedback

## Fixes

- [x] `scenarios.py`: Pre-insert `pipeline_runs` row with status `running` BEFORE background task starts
- [x] `orchestrator.py`: Write signals/insight/plan to DB incrementally, wrap all in try/except → set `failed` on error
- [x] `plan.py`: Wrap `generate_candidates()` in try/except with realistic fallback candidates
- [x] `state.py`: Return both `"insight"` AND `"insight_report"` keys in `/logs/{plan_id}`
